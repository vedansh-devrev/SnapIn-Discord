import fetch from 'node-fetch';
export async function createDiscordTag(tagName, DEVREV_PAT) {
	// Create a Discord Tag
	const tag_data = {
		name: tagName,
	}
	let endpoint = `tags.create`;
	let tagID;
	try {
		const resp = await DevrevAPIRequest(endpoint, {
			method: "POST",
			body: tag_data,
		}, DEVREV_PAT);
		tagID = resp.tag.id;
	} catch (err) {
		console.error(err);
	}
	return tagID;
}

export async function checkIfTagExists(tagName, DEVREV_PAT) {
	let endpoint = `tags.list`
	let nextCursor, tagsArray, tagID;
	// First Iteration Fetch
	try {
		const resp = await DevrevAPIRequest(endpoint, {
			method: "GET",
		}, DEVREV_PAT);
		nextCursor = resp.next_cursor;
		tagsArray = resp.tags;
	} catch (err) {
		console.error(err);
	}
	let tagExists = false;
	for (const tag of tagsArray) {
		if (tag.name === tagName) {
			tagID = tag.id;
			tagExists = true;
			break;
		}
	}
	console.log("next cursor: ", nextCursor);
	// Fetching all possible iterations
	if (!tagExists) {
		while (nextCursor != undefined) {
			endpoint = `tags.list?cursor=${nextCursor}`;
			try {
				const resp = await DevrevAPIRequest(endpoint, {
					method: "GET",
				}, DEVREV_PAT);
				nextCursor = resp.next_cursor;
				tagsArray = resp.tags;
			} catch (err) {
				console.error(err);
			}
			for (const tag of tagsArray) {
				if (tag.name === tagName) {
					tagID = tag.id;
					tagExists = true;
					break;
				}
			}
			if (tagExists == true)
				break;
		}
	}
	return [tagExists, tagID];
}

export async function DiscordAPIRequest(endpoint, options, TOKEN_TYPE, DISCORD_TOKEN) {
	// Append endpoint to root API URL
	const url = 'https://discord.com/api/v10/' + endpoint;
	// Stringify payloads
	if (options.body) options.body = JSON.stringify(options.body);
	// Use node-fetch to make requests
	const res = await fetch(url, {
		headers: {
			Authorization: `${TOKEN_TYPE} ${DISCORD_TOKEN}`,
			'Content-Type': 'application/json; charset=UTF-8',
		},
		...options
	});
	// throw API errors
	if (!res.ok) {
		const data = await res.json();
		console.log(res.status);
		throw new Error(JSON.stringify(data));
	}
	// return original response
	return res;
}

export async function DevrevAPIRequest(endpoint, options, DEVREV_PAT) {
	// append endpoint to root API URL
	const url = 'https://api.dev.devrev-eng.ai/' + endpoint;
	// Stringify payloads
	if (options.body) options.body = JSON.stringify(options.body);
	// Use node-fetch to make requests
	const res = await fetch(url, {
		headers: {
			Authorization: `${DEVREV_PAT}`,
			'Content-Type': 'application/json; charset=UTF-8',
		},
		...options
	});
	// throw API errors
	if (!res.ok) {
		const data = await res.json();
		console.log(res.status);
		throw new Error(JSON.stringify(data));
	}
	return await res.json();
}