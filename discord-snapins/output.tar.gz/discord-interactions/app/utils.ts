import fetch from "node-fetch";

export async function DiscordAPIRequest(endpoint, options, TOKEN_TYPE, DISCORD_TOKEN) {
	// Append endpoint to root API URL
	const url = 'https://discord.com/api/v10/' + endpoint;
	// Stringify payloads
	if (options.body) options.body = JSON.stringify(options.body);
	// Use node-fetch to make requests
	const res = await fetch(url, {
		headers: {
			Authorization: `${TOKEN_TYPE} ${DISCORD_TOKEN}`,
			'Content-Type': 'application/json; charset=UTF-8',
		},
		...options
	});
	// throw API errors
	if (!res.ok) {
		const data = await res.json();
		throw new Error(JSON.stringify(data));
	}
	// return original response
	return res;
}

export async function DevrevAPIRequest(endpoint, options, DEVREV_PAT) {
	// Append endpoint to root DevRev API URL
	const url = 'https://api.dev.devrev-eng.ai/' + endpoint;
	// Stringify payloads
	if (options.body) options.body = JSON.stringify(options.body);
	// Use node-fetch to make requests
	const res = await fetch(url, {
		headers: {
			Authorization: DEVREV_PAT,
			'Content-Type': 'application/json; charset=UTF-8',
		},
		...options
	})
	// Throw API errors
	if (!res.ok) {
		const errorData = await res.json();
		throw new Error(JSON.stringify(errorData));
	}
	return await res.json();
}

export async function createDiscordTag(tagName, DEVREV_PAT) {
	// Create a Discord Tag
	const tag_data = {
		name: tagName,
	}
	let endpoint = `tags.create`;
	let tagID;
	try {
		const resp = await DevrevAPIRequest(endpoint, {
			method: "POST",
			body: tag_data,
		}, DEVREV_PAT);
		tagID = resp.tag.id;
	} catch (err) {
		console.error(err);
	}
	return tagID;
}

export async function checkIfTagExists(tagName, DEVREV_PAT) {
	let endpoint = `tags.list`
	let nextCursor, tagsArray, tagID;
	console.log("checking first iteration for tags")
	// First Iteration Fetch
	try {
		const resp = await DevrevAPIRequest(endpoint, {
			method: "GET",
		}, DEVREV_PAT);
		nextCursor = resp.next_cursor;
		tagsArray = resp.tags;
		console.log(nextCursor, tagsArray);
	} catch (err) {
		console.error(err);
	}
	console.log(tagsArray)
	let tagExists = false;
	for (let tag of tagsArray) {
		if (tag.name === tagName) {
			tagID = tag.id;
			tagExists = true;
			break;
		}
	}
	console.log(tagExists, tagID);
	// Fetching all possible iterations
	console.log("checking later iteration for tags")
	if (!tagExists) {
		while (nextCursor != undefined) {
			endpoint = `tags.list?cursor=${nextCursor}`;
			try {
				const resp = await DevrevAPIRequest(endpoint, {
					method: "GET",
				}, DEVREV_PAT);
				nextCursor = resp.next_cursor;
				tagsArray = resp.tags;
			} catch (err) {
				console.error(err);
			}
			for (let tag of tagsArray) {
				if (tag.name === tagName) {
					tagID = tag.id;
					tagExists = true;
					break;
				}
			}
			if (tagExists == true)
				break;
		}
	}
	console.log(tagExists, tagID);
	return [tagExists, tagID];
}

export async function getWorkItemFromDisplayID(workDisplayID, workType , devrevPATToken)
{
	let endpoint = `works.list?type=${workType}`
	let nextCursor, worksArray;
	// // First Iteration Fetch
	try {
		const resp = await DevrevAPIRequest(endpoint, {
			method: "GET",
		}, devrevPATToken);
		nextCursor = resp.next_cursor;
		worksArray = resp.works;
	} catch (err) {
		console.error(err);
	}
	// workObject is the final work-item which is sent (if it exists for a given work display ID)
	let workExists = false, workObject;
	for (let work of worksArray) {
		if (work.display_id === workDisplayID) {
			workObject = work;
			workExists = true;
			break;
		}
	}
	// Fetching all possible iterations
	if (!workExists) {
		while (nextCursor != undefined) {
			endpoint = `works.list?cursor=${nextCursor}&type=${workType}`;
			try {
				const resp = await DevrevAPIRequest(endpoint, {
					method: "GET",
				}, devrevPATToken);
				nextCursor = resp.next_cursor;
				worksArray = resp.works;
			} catch (err) {
				console.error(err);
			}
			for (let work of worksArray) {
				if (work.display_id === workDisplayID) {
					workObject = work;
					workExists = true;
					break;
				}
			}
			if (workExists == true)
				break;
		}
	}
	return [workExists, workObject];
}
