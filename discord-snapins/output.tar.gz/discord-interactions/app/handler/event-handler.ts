import {HandleMessageCommandInteractions} from "./message-commands";
import {HandleSlashCommandInteractions} from "./slash-commands";

export {HandleMessageCommandInteractions, HandleSlashCommandInteractions};